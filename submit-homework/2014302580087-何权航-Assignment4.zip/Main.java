import java.io.IOException;
import java.sql.SQLException;


public class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		// TODO �Զ����ɵķ������
		//GetData data =new GetData();
		//data.run();
		Search search=new Search();
		search.txt="C";
		search.run();
		for(int i=0;i<26;i++){
			if(search.SearchData[i]!=null){
		         System.out.print(search.SearchData[i]);
			}
				}
	}
}
