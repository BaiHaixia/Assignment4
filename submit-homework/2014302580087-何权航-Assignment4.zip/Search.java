import java.io.IOException;
import java.sql.SQLException;


public class Search {
	String s = null;
	int tf=0;
	int TF[]=new int[100];
	String SearchData[]=new String[100];
	String m_data[]=new String[100];
	String txt="C";
	public void run() throws ClassNotFoundException, SQLException, IOException
	{
		 GetData data=new GetData();
		 data.run();
		 //����ʦ���ݴ���һ������
		 for(int i=0;i<26;i++){
		 m_data[i]=data.data[i];
}
		 //��TFֵ��������
		 for(int j=0;j<26;j++){
		 s=data.data[j];
		 String[] a=s.split(" ");
		 for(int i=0;i<a.length;i++){
		 if(a[i].contains(txt)){
			 tf++;
		 }
	  }
		TF[j]=tf;
		tf=0;	
   }
		 for(int i=25;i>0;i--){
         	for(int j=0;j<i;j++){
         		if(TF[j]<TF[j+1]){
         			TF[0]=TF[j];TF[j]=TF[j+1];TF[j+1]=TF[0];
         			m_data[0]=m_data[j];m_data[j]=m_data[j+1];m_data[j+1]=m_data[0];
         		}
         	}
         }
		 for(int i=0;i<26;i++){
			 if(TF[i]!=0){
				 SearchData[i]=m_data[i];
			 }
		 }
		 //System.out.print(m_data[0]);

	}
}
