import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class GetData {
	 String url = "jdbc:mysql://127.0.0.1:3306/test" ;    
     String username = "root" ;   
     String password = "123456" ;
     PreparedStatement ps;
     String data[]=new String[100];
     int count=0;
	public void run() throws ClassNotFoundException, SQLException, IOException {
		// TODO �Զ����ɵķ������
		Class.forName("com.mysql.jdbc.Driver") ; //����MySql��������  
        Connection con =DriverManager.getConnection(url , username , password ) ;//�������ݿ������
        Statement st=con.createStatement();
        ResultSet rs = st.executeQuery("select * from 2014302580087_professor_info");
        while (rs.next()) {			
		data[count]=  "professor's name:"+rs.getString("name") + "\r\n"
					+ "professor's educationBackground:"+rs.getString("educationBackground") + "\r\n" 
					+ "professor's researchInterests:"+rs.getString("researchInterests") + "\r\n"
					+ "professor's email:"+rs.getString("email") + "\r\n"
					+ "professor's phone:"+rs.getString("phone"); 
				count++;
		}
        
        //System.out.print(data[0]);
	}
}
